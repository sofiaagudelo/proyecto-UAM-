console.log("hello word");

var a = 1;
var b = 2;
var r = a + b;
console.log ("resultado:" + r);

var f = 1;
var g = 2;
var s = f * g;
console.log ("resultado:" + s);

var m = 200
var o = 2;
var numerosPrimos = [];

for (; o < m; o++) {

  if (primo(o)) {
    numerosPrimos.push(o);
  }
  
}

console.log("Los numero primos hasta el 500.000 son: " + numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}